import static org.junit.Assert.*;

import org.junit.Test;

public class DivideCalcTest {

	@Test
	public void test() {
		int output = CalcTest.divide(9,9);   // Passing numbers to divide
		assertEquals(1,output);              // The method give answer 1
		assertNull(CalcTest.divide(9,9));    // Method shouldn't give any return value
		assertNotNull(CalcTest.divide(9,9)); // Method should give any return value
		assertSame(1,output);                // Output should be the same
		assertNotSame(2,output);             // Check whether output is not same.
	}

}
