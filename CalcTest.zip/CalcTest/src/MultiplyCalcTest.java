import static org.junit.Assert.*;

import org.junit.Test;

public class MultiplyCalcTest {

	@Test
	public void test() {
		int output = CalcTest.multiply(9,9);   // Passing numbers to multiply method
		assertEquals(81,output);               // The method give answer 81
		assertNull(CalcTest.multiply(9,9));    // Method shouldn't give any return value
		assertNotNull(CalcTest.multiply(9,9)); // Method should give any return value
		assertSame(81,output);                 // Output should be the same 81.
		assertNotSame(91,output);              // Check whether output is not same.
	}

}
