import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AdditionCalcTest.class, DivideCalcTest.class, MinusCalcTest.class, MultiplyCalcTest.class })
public class AllTests {
 // This is test suite class to execute all classes. 
}
