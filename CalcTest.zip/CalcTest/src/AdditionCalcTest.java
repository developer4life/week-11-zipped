import static org.junit.Assert.*;

import org.junit.Test;

public class AdditionCalcTest {
 
	@Test
	public void testAddition() {
		//fail("Not yet implemented");
		int output = CalcTest.addition(9,9);   // Passing numbers to addition
		assertEquals(18,output);               // The method give answer 18
		assertNull(CalcTest.addition(0,0));    // Method shouldn't give any return value
		assertNotNull(CalcTest.addition(0,0)); // Method should give any return value
		assertSame(18,output);                 // Output should be the same
		assertNotSame(17,output);              // Check whether output is not same.
	}
	
	
	

	
}
