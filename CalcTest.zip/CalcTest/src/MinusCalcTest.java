import static org.junit.Assert.*;

import org.junit.Test;

public class MinusCalcTest {

	@Test
	public void test() {
		int output = CalcTest.minus(9,8);     // Passing numbers to minus
		assertEquals(1,output);               // The method give answer 1
		assertNull(CalcTest.minus(9,9));      // Method shouldn't give any return value
		assertNotNull(CalcTest.minus(9,9));   // Method should give any return value
		assertSame(1,output);                 // Output should be the same
		assertNotSame(2,output);              // Check whether output is not same.
	}

}
